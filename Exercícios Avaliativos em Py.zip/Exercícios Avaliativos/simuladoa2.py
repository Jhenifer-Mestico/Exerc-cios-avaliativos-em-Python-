#Ex 7
for i in range(3):
    inicio = int(input("Inicio:"))
    final = int(input("Fim:"))
    
    contImpar = 0
    contPar = 0
    for x in range(inicio, final + 1):
        if (x % 2 == 0):
            contPar = contPar + 1
        else: contImpar = contImpar + 1
    print("Números pares:", contPar, "Números ímpares:", contImpar)
            
            
        
