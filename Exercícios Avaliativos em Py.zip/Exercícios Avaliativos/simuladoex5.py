frutas = ['banana', 'caju', 'abacaxi', 'morango', 'carambola' ,'kiwi']

condicao = True
while condicao:
    fruta = input('Digite a fruta a ser removida:')

    if (fruta != 'abacaxi'):
        frutas.remove(fruta)
        

    condicao = (input('Deseja remover mais itens? (s/n)') == 's')

for i in frutas:
    print('Fruta:', i)

    
