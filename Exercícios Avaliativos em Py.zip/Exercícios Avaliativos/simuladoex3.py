#ex 3
continua = 's'
while continua == 's':
    lados = []

    lados = []
    lados.append(int(input('Tamanho lado 1:')))
    lados.append(int(input('Tamanho lado 2:')))
    lados.append(int(input('Tamanho lado 3:')))

    if (lados[0] == lados[1] and lados[1] == lados[2]):
        print('Equilátero')
                  
    elif (lados[0] == lados[1] or lados[0] == lados[2]):
        print('Isósceles')

    elif (lados[1] == lados[2]):
        print('Isósceles')

    else:
        print('Escaleno')

    continua = input('Deseja continuar? (s/n)')
    
    
    
    
